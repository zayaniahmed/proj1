#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);


void
on_button6_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget *objet,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget *objet,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkWidget *objet,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_activate                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
